<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $firstName = isset($_POST['firstName']) ? $_POST['firstName'] : "";
    $lastName = isset($_POST['lastName']) ? $_POST['lastName'] : "";
    $email = isset($_POST['email']) ? $_POST['email'] : "";
    $number = isset($_POST['number']) ? $_POST['number'] : "";
    $message = isset($_POST['message']) ? $_POST['message'] : "";

    // Process the data further (e.g., database insertion, email sending, etc.)
    // Your database insertion code goes here
}

$conn = new mysqli('localhost', 'root', '', 'contact');
if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
}else{
    $stmt = $conn->prepare("insert into registration (firstName, lastName, email, number, message) values (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssis", $firstName, $lastName, $email, $number, $message);
    $stmt->execute();
    echo "Registration Successful.....";
    $stmt->close();
    $conn->close();

    
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration Form</title>
</head>
<body>
    <?php if (!empty($message)) { ?>
        
        <a href="index.html">Go to Home Page</a>
    <?php } else { ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <!-- Your form fields go here -->
            <input type="submit" value="Submit">
        </form>
    <?php } ?>
</body>
</html>
